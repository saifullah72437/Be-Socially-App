package com.saif.besocially.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.saif.besocially.Adapters.StoryAdapter;
import com.saif.besocially.Adapters.dashboardAdapter;
import com.saif.besocially.Models.dashboardModel;
import com.saif.besocially.Models.storyModel;
import com.saif.besocially.R;

import java.util.ArrayList;


public class HomeFragment extends Fragment {
RecyclerView storyRV, dashboardRV;
ArrayList<storyModel> list;
ArrayList<dashboardModel> dashboardlist;

    public HomeFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        storyRV = view.findViewById(R.id.storyRV);
        list = new ArrayList<>();
        list.add(new storyModel(R.drawable.image1, R.drawable.livebtn, R.drawable.profile,"Saifullah"));
        list.add(new storyModel(R.drawable.image2, R.drawable.livebtn, R.drawable.profile,"Ali"));
        list.add(new storyModel(R.drawable.image3, R.drawable.livebtn, R.drawable.profile,"Haider"));
        list.add(new storyModel(R.drawable.image4, R.drawable.livebtn, R.drawable.profile,"Akbar"));
        list.add(new storyModel(R.drawable.image5, R.drawable.livebtn, R.drawable.profile,"Husan"));
        StoryAdapter storyAdapter = new StoryAdapter(list, getContext());
        LinearLayoutManager storyLayoutManager = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL, false);
        storyRV.setLayoutManager(storyLayoutManager);
        storyRV.setNestedScrollingEnabled(false);
        storyRV.setAdapter(storyAdapter);

        dashboardRV = view.findViewById(R.id.dashboardRv);
        dashboardlist = new ArrayList<>();
        dashboardlist.add(new dashboardModel(R.drawable.profile, R.drawable.image1, R.drawable.bookmark_border, "Saif", "Andriod",
                "34", "45", "67"));
        dashboardlist.add(new dashboardModel(R.drawable.profile, R.drawable.image2, R.drawable.bookmark_border, "Ali", "Teacher",
                "34", "45", "67"));
        dashboardlist.add(new dashboardModel(R.drawable.profile, R.drawable.image3, R.drawable.bookmark_border, "Abrax", "Developer",
                "34", "45", "67"));
        dashboardlist.add(new dashboardModel(R.drawable.profile, R.drawable.image4, R.drawable.bookmark_border, "Waqas", "Andriod",
                "34", "45", "67"));
        dashboardlist.add(new dashboardModel(R.drawable.profile, R.drawable.image5, R.drawable.bookmark_border, "Hamza", "Andriod",
                "34", "45", "67"));
        dashboardAdapter dashboardAdapters = new dashboardAdapter(dashboardlist, getContext());
        LinearLayoutManager dashboardlayoutManager = new LinearLayoutManager(getContext());
        dashboardRV.setLayoutManager(dashboardlayoutManager);
        dashboardRV.setNestedScrollingEnabled(false);
        dashboardRV.setAdapter(dashboardAdapters);

        return view;
    }
}